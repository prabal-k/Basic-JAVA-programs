public class Animal {
    public void eat() {
        System.out.println("I am Eating");

    }
    public void walk()
    {
        System.out.println("I am walking");
    }
}
