public class Main {
    public static void main(String[] args)
    {
        System.out.println("Hello world");
        Bird bird = new Bird();
        bird.fly();
        bird.eat();
        bird.walk();
    }
}